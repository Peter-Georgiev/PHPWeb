<form>
    <div>
        <h1>Sale data</h1>
        <input type="text" name="sale_id" placeholder="Sale ID"/>
        <input type="text" name="date_time_sale" placeholder="Date time"/>
        <input type="text" name="amount" placeholder="amount"/>
        <input type="text" name="currency" placeholder="Option currency"/>
    </div>
    <div>
        <input type="submit" name="update" value=" Update "/>
    </div>
</form>