<form>
    <div>
        <h1>Customer data</h1>
        <input type="text" name="customer_id" placeholder="Customer ID"/>
        <input type="text" name="first_name" placeholder="First name"/>
        <input type="text" name="last_name" placeholder="Last name"/>
    </div>
    <div>
        <input type="submit" name="update" value=" Update "/>
    </div>
</form>