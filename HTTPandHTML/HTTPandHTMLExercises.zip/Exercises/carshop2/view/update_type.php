<form>
    <h1>Problem 8. Create Update Functionality</h1>
    <div>
        <select name="type">
            <option value="car">Car</option>
            <option value="customer">Customer</option>
            <option value="sale">Sale</option>
        </select>
        <input type="submit" name="update_type" value=" Update type "/>
    </div>
</form>
