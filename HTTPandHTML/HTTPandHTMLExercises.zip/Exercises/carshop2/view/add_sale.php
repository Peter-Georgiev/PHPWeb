<form>
    <h1>Problem 1. Add a Car, Customer and Sale</h1>
    <div>
        <h1>Car data</h1>
        <input type="text" name="make" placeholder="Car make"/>
        <input type="text" name="model" placeholder="Car model"/>
        <input type="number" name="year" placeholder="Car year"/>
    </div>
    <div>
        <h1>Customer data</h1>
        <input type="text" name="first_name" placeholder="First name"/>
        <input type="text" name="last_name" placeholder="Last name"/>
    </div>
    <div>
        <h1>Sale</h1>
        <input type="text" name="amount" placeholder="Currency price (BGN 100)"/>
    </div>
    <div>
        <input type="submit" name="addSale" value=" Insert "/>
    </div>
</form>