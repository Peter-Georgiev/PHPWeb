<html>
	<head>
		<title>Car Sales App</title>
		<link href="view/style.css" rel="stylesheet" type="text/css"/>
	</head>
	<body>