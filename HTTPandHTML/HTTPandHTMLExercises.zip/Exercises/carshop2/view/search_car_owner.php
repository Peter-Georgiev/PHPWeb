<form>
    <h1>Problem 6. Search a Car & Owner by Make</h1>
    <div>
        <h1>Car data</h1>
        <input type="text" name="make" placeholder="Car make"/>
    </div>
    <div>
        <input type="submit" name="search" value=" Search "/>
    </div>
</form>