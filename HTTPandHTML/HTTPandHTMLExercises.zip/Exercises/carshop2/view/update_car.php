<form>
    <div>
        <h1>Car data</h1>
        <input type="text" name="car_id" placeholder="Car ID"/>
        <input type="text" name="make" placeholder="Car make"/>
        <input type="text" name="model" placeholder="Car model"/>
        <input type="number" name="year" placeholder="Car year"/>
    </div>
    <div>
        <input type="submit" name="update" value=" Update "/>
    </div>
</form>