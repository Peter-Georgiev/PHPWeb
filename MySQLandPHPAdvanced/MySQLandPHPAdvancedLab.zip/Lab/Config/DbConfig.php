<?php
declare(strict_types=1);

namespace Config;

class DBConfig
{
    const DB_HOST     = 'localhost';
    const DB_NAME     = 'php-course';
    const DB_USER     = 'root';
    const DB_PASSWORD = '4545';
}