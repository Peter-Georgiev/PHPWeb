<?php

namespace TaskManagement\Service;


use TaskManagement\DTO\TaskDTO;
use TaskManagement\Repository\TaskRepositoryInterface;

class TaskService implements TaskServiceInterface
{
    /** @var  TaskRepositoryInterface */
    private $taskRepository;

    /**
     * TaskService constructor.
     * @param TaskRepositoryInterface $taskRepository
     */
    public function __construct(TaskRepositoryInterface $taskRepository)
    {
        $this->taskRepository = $taskRepository;
    }

    public function add(TaskDTO $task): bool
    {
        //todo
    }

    public function edit(TaskDTO $task, int $id): bool
    {
        //todo
    }

    public function remove(int $id): bool
    {
        //todo
    }

    public function viewPerId(int $id): TaskDTO
    {
        //todo
    }
}