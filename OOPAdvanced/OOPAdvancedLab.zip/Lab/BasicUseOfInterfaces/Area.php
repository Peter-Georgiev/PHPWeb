<?php
declare(strict_types=1);

interface Area
{
    public function getSurface(): string;
}
