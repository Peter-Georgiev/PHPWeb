<?php
declare(strict_types=1);

interface TouchPad
{
    public function moveFinger();

    public function clickFinger();
}