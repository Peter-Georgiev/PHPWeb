<?php
declare(strict_types=1);

interface Circumference
{
    public function getCircumference(): string;
}