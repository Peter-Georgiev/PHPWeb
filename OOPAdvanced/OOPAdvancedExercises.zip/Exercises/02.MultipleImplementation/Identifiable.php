<?php
declare(strict_types=1);

interface Identifiable
{
    public function setId(float $id);

    //public function setIdBirtdate(int $Id, string $birthDate);
}