<?php
declare(strict_types=1);

interface Birthable
{
    public function setBirthdate(string $birthDate );

    //public function setIdBirtdate(string $birthDate, int $Id);
}