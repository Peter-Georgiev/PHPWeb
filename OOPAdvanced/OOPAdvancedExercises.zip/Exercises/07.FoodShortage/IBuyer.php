<?php
declare(strict_types=1);

interface IBuyer
{
    public function buyFood(int $food);
}