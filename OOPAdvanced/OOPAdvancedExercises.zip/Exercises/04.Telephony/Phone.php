<?php
declare(strict_types=1);

interface Phone
{
    public function model();

    public function browsing(string $browsingWeb);
}