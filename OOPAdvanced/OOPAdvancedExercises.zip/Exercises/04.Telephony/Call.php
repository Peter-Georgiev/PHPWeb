<?php
declare(strict_types=1);

interface Call
{
    public function call(string $callNumber);
}