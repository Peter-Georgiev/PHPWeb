<?php
declare(strict_types=1);

interface Actions
{
    public function useBreke(): string;

    public function useGas(): string;
}