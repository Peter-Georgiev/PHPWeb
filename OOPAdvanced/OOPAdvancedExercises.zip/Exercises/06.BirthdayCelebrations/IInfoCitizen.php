<?php
declare(strict_types=1);

interface IInfoCitizen
{
    public function name();

    public function birthdate();
}