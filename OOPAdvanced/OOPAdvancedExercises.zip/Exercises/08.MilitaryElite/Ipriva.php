<?php
declare(strict_types=1);

interface Ipriva
{
    public function getSelary();
}