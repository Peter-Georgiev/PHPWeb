<?php
declare(strict_types=1);

interface Isoldier
{
    public function getId();

    public function getFirstName();

    public function getLastName();
}