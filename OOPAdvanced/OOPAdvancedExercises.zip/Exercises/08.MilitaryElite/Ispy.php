<?php
declare(strict_types=1);

interface Ispy
{
    public function getCodeNumber();
}