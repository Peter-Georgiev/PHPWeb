<?php
declare(strict_types=1);

interface IEngineer
{
    public function getRepairs();
}