<?php
declare(strict_types=1);

interface IIidentification
{
    public function name();

    public function id();
}