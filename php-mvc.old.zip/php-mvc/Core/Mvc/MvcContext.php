<?php

namespace Core\Mvc;


class MvcContext implements MvcContextInterface
{
    /** @var  MvcContextInterface */
    private $mvcContext;

    private $methodName;
    private $fulClassName;

    /**
     * @return MvcContextInterface
     */
    public function getMvcContext(): MvcContextInterface
    {
        return $this->mvcContext;
    }

    /**
     * @param MvcContextInterface $mvcContext
     */
    public function setMvcContext(MvcContextInterface $mvcContext)
    {
        $this->mvcContext = $mvcContext;
    }

    /**
     * @return mixed
     */
    public function getMethodName()
    {
        return $this->methodName;
    }

    /**
     * @param mixed $methodName
     */
    public function setMethodName($methodName)
    {
        $this->methodName = $methodName;
    }

    /**
     * @return mixed
     */
    public function getFulClassName()
    {
        return $this->fulClassName;
    }

    /**
     * @param mixed $fulClassName
     */
    public function setFulClassName($fulClassName)
    {
        $this->fulClassName = $fulClassName;
    }
}