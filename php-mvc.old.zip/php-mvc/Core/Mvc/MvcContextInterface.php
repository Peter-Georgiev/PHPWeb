<?php
/**
 * Created by PhpStorm.
 * User: Peter
 * Date: 15.11.2017
 * Time: 22:14 ч.
 */

namespace Core\Mvc;


interface MvcContextInterface
{

}