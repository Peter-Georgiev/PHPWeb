<?php
/** @var \Model\UserRegisterViewModel $model */

echo "I am user registration: " . $model->getName() .
     " id: " . $model->getId() . "!";