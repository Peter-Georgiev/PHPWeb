<?php /** @var \DTO\UserViewModel $data */ ?>
<h1>Hello Mr/Ms <?= $data->getFirstName();?> <?= $data->getLastName();?>!</h1>
