<?php
/** @var \Model\UserRegisterViewModel $model */

echo "DELETE user: " . $model->getName() .
    " id: " . $model->getId() . "!";