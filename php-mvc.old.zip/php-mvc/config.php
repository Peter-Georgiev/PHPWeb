<?php
define('DEFAULT_CONTROLLER', 'welcome');

define('DEFAULT_ACTION', 'index');

define('TEMPLATES_FOLDER', 'templates');