<?php

namespace Controller;


interface ControllerInterface
{
    public function register(string $name, int $id = 0);

    public function delete(string $name, int $id);

    public function hello(string $firstName, string $lastName);

    public function index();
}