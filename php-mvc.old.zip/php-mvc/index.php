<?php
include 'config.php';
spl_autoload_register();

$params = explode('/', $_SERVER['REQUEST_URI']);

array_shift($params);
array_shift($params);

$controllerName = array_shift($params);
$actionName = array_shift($params);

//$context = new \Core\Mvc\MvcContext();

$app = new \Core\Application($controllerName, $actionName, $params);
$app->start();
