<?php
declare(strict_types=1);

class Father extends Person
{
    public function getGenerationNum()
    {
        return 1;
    }
}