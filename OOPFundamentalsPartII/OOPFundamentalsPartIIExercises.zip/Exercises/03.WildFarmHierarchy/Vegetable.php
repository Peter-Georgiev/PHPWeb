<?php
declare(strict_types=1);

class Vegetable extends Food
{

}
