<?php
declare(strict_types=1);

class Meat extends Food
{
}