<?php
declare(strict_types=1);

class Son extends Father
{
    public function getGenerationNum()
    {
        return 2;
    }
}