<?php
declare(strict_types=1);

class GrandSon extends Son
{
    public function getGenerationNum()
    {
        return 3;
    }
}