<?php
declare(strict_types=1);

$db_host     = "localhost";
$db_name     = "geography";
$db_username     = "root";
$db_password = "peroxmen";
