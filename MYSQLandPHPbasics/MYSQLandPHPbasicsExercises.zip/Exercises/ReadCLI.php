<?php
/**
 * Created by PhpStorm.
 * User: Peter
 * Date: 18.10.2017
 * Time: 10:28 ч.
 */

class ReadCLI
{

}