<form>
    <a href="http://localhost/PHPWeb/HTTPwithPHP/Exercises/employee2/?controller=EmployeeController&action=view"
    >View Emploeyyes</a>
</form>
	