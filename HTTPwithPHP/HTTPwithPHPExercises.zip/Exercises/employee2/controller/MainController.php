<?php
declare(strict_types=1);

class MainController extends Controller
{

    public function main()
    {
        // Todo
    }
}